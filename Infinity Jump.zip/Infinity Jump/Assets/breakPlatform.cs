﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class breakPlatform : MonoBehaviour
{
    public GameObject breakPlatPrefab;
    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.GetComponent<Rigidbody2D>().velocity.y <= 0)
        {
            //breakPlatPrefab = collision.gameObject;
            collision.gameObject.GetComponent<Rigidbody2D>().AddForce(Vector3.up * 800f);
            gameObject.transform.position = new Vector2(-25f, transform.position.y);
           // breakPlatPrefab.transform.position = new Vector2(-10f, breakPlatPrefab.transform.position.y);
        }

    }
    
}
